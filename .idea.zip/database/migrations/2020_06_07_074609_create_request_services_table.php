<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRequestServicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('request_services', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedBigInteger('customer_id');
            $table->enum('type',['transport','tow','fuel','tire','battery'])->nullable();
            $table->unsignedBigInteger('company_id')->nullable();
            $table->unsignedBigInteger('service_id');
            $table->string('status')->default('pending');
            $table->string('start_qr')->nullable();
            $table->string('end_qr')->nullable();
            $table->integer('points')->nullable();
            $table->decimal('request_lat',8)->nullable();
            $table->decimal('request_long',8)->nullable();
            $table->text('note')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('request_services');
    }
}
