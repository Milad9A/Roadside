<?php

namespace App\Models\UserServices;

use Illuminate\Database\Eloquent\Model;

class UserServices extends Model
{
    //
}
