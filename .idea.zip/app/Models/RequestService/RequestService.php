<?php

namespace App\Models\RequestService;

use App\Models\TowServiceDetail\TowServiceDetails;
use App\Models\TransportServiceDetail\TransportServiceDetails;
use Illuminate\Database\Eloquent\Model;

class RequestService extends Model
{
    protected $fillable = [
        'customer_id',
        'company_id',
        'service_id',
        'status',
        'start_qr',
        'end_qr',
        'points',
        'type',
        'note',
        'request_lat',
        'request_long',
        'time_request',
        'date_request'
    ];

    public function towServiceDetails()
    {
        return $this->hasOne(TowServiceDetails::class,'request_services_id','id');
    }
    public function transportServiceDetails()
    {
        return $this->hasOne(TransportServiceDetails::class,'request_services_id','id');
    }
}
