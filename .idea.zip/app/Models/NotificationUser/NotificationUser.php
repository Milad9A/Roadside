<?php

namespace App\Models\NotificationUser;

use Illuminate\Database\Eloquent\Model;

class NotificationUser extends Model
{
    //
}
