<?php
$ta = $_server['DOCUMENT_ROOT'].'/institute/storage/app/public';
$link = $_SERVER['DOCUMENT_ROOT'].'/institute/public/storage';
symlink($ta,$link);
echo 'success';
?>